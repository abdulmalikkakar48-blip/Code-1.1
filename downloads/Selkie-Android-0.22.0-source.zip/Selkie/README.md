# Selkie — application Android de réduction du temps d'écran

## Version actuelle 0.22.0 — vingt illustrations à colorier

Quotidien → Coloriage → **Illustrations** propose **20 dessins originaux gratuits** : 8 dans Fleurs, 7 dans Paysages et 5 dans Motifs. Les huit modèles précédents sont conservés ; douze s’ajoutent : tournesols, nénuphars, iris, magnolia, forêt, dunes, jardin en terrasses, lac étoilé, rosace botanique, feuilles entrelacées, spirales marines et montagnes à motifs. La galerie prépare les miniatures à mesure qu’elles deviennent visibles.

Les douze pages **À carreaux** restent disponibles séparément. Les anciennes couleurs sont conservées. Seize couleurs, gomme, remplissage par zone, zoom, numéros facultatifs et sauvegarde locale restent disponibles, sans nouvelle permission ni accès réseau. Export JSON schéma 6 inchangé.

[APK 0.22.0](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.22.0.apk) · [Sources exactes](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.22.0-source.zip) · [Validation](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/VALIDATION-0.22.0.md).

VersionCode 35, Android 10+, même certificat de développement. Plafond de 100 points, dé, calendrier, lectures et coach préparé FR/EN conservés. Prix prévus : Premium 5 €/mois ou 60 €/an, Ultra 10 €/mois ou 120 €/an, sans réduction ni paiement réel dans cet APK de test.

## Archive 0.21.0

## Version 0.21.0 — paysages et coloriages à motifs

Quotidien → Coloriage → **Illustrations** propose maintenant huit dessins originaux, regroupés dans **Fleurs**, **Paysages** et **Motifs**. Aux quatre modèles floraux s’ajoutent une cascade, un lac alpin, un jardin côtier et un arbre aux motifs décoratifs. La catégorie **Toutes** permet de parcourir l’ensemble. Les aperçus colorés servent d’exemples ; chaque nouvelle feuille personnelle commence blanche.

Les seize couleurs, la gomme, le remplissage au toucher, les numéros facultatifs, le zoom à 300 % et Annuler/Rétablir restent disponibles. Les couleurs s’enregistrent sur le téléphone. Les quatre anciens dessins et les douze pages **À carreaux** conservent leurs couleurs ; l’export JSON reste au schéma 6. Tous les coloriages sont gratuits, sans téléchargement d’images, nouvelle permission ni accès réseau.

[APK 0.21.0](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.21.0.apk) · [Sources exactes](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.21.0-source.zip) · [Validation](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/VALIDATION-0.21.0.md).

VersionCode 34, Android 10+, même certificat de développement. Le plafond de 100 points, les quatre modes du dé, le calendrier, les lectures et le coach préparé FR/EN sont conservés. Prix prévus inchangés : Premium 5 €/mois ou 60 €/an, Ultra 10 €/mois ou 120 €/an, sans réduction ni paiement réel dans cet APK de test.

## Archive 0.20.0

## Version 0.20.0 — illustrations florales à colorier

Quotidien → Coloriage → **Illustrations** ajoute quatre dessins originaux aux contours courbes : Jardin de roses, Bouquet sauvage, Tulipes de printemps et Feuillages. Touche une zone pour la remplir avec l’une des seize couleurs, efface avec la gomme, agrandis jusqu’à 300 % et déplace le dessin. Les repères numérotés sont facultatifs ; les couleurs restent libres. Chaque zone s’enregistre sur ce téléphone, avec Annuler/Rétablir sur les cinquante dernières actions de la page ouverte.

Les douze pages existantes et leurs couleurs sont conservées sous **À carreaux**. Les quatre illustrations sont gratuites dans toutes les offres, sans téléchargement, permission ou réseau supplémentaire. Les aperçus colorés ne préremplissent jamais la feuille personnelle. Export JSON schéma 6 et effacement global incluent séparément les deux formats.

[APK 0.20.0](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.20.0.apk) · [Sources exactes](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.20.0-source.zip) · [Validation](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/VALIDATION-0.20.0.md).

VersionCode 33, Android 10+, même certificat de développement. Plafond 100 points, quatre modes du dé, calendrier, lectures et coach préparé FR/EN conservés. Prix prévus inchangés : Premium 5 €/mois ou 60 €/an, Ultra 10 €/mois ou 120 €/an, sans réduction ni paiement réel dans cet APK de test.

## Archive 0.19.0

## Version 0.19.0 — 100 points maximum et dé Points

Les points d’honneur restent entre 0 et 100. Un ancien solde supérieur est ramené à 100 sans effacer la progression ; les récompenses sous le plafond et les pénalités habituelles sont conservées.

Quotidien → Dé ajoute le mode facultatif **Points**, gratuit : face 1 retire 1 point, jusqu’à la face 6 qui retire 6 points, sans passer sous zéro. La perte est annoncée avant le bouton ; une tentative interrompue reprend le même reçu sans second retrait. Les modes Activité, Appli et Semaine restent sans perte de points. Les douze coloriages, le calendrier et le coach local FR/EN sont conservés.

[APK 0.19.0](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.19.0.apk) · [Sources exactes](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.19.0-source.zip) · [Validation](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/VALIDATION-0.19.0.md).

VersionCode 32, Android 10+, même certificat de développement. Export JSON schéma 5 avec le dernier reçu du dé Points. Premium reste à 5 €/mois ou 60 €/an ; Ultra à 10 €/mois ou 120 €/an, sans réduction ni achat réel dans cet APK de test.

## Archive 0.18.0

## Version 0.18.0 — dé plus clair, calendrier et dessins

Le dé distingue le choix du mode, la proposition et la confirmation. L’idée tirée reste près du bouton et est amenée à l’écran après le lancer ; les détails des six activités sont repliables. Le calendrier reçoit un en-tête illustré, des repères de dates et des cartes de tâches. À taille de texte normale, les sept jours de la semaine sont visibles sans défilement horizontal ; une grande police garde une grille défilante et un sélecteur de date accessible.

Coloriage passe à douze pages gratuites : les huit motifs existants et quatre petits dessins originaux à carreaux (arbre, fleur, livre ouvert, paysage). Une galerie montre les modèles et la palette précède la grille. Les cellules déjà coloriées sont conservées. La navigation de Quotidien reste compacte et amène la rubrique choisie dans la zone visible ; un bouton explicite ouvre les dessins depuis Jour.

[APK 0.18.0](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.18.0.apk) · [Sources exactes](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.18.0-source.zip) · [Validation](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/VALIDATION-0.18.0.md).

VersionCode 31, Android 10+, même certificat de développement. Dé et coloriage gratuits dans toutes les offres ; limites, points, calendrier, seize lectures et coach conservés. Prix prévus inchangés : Premium 5 €/mois ou 60 €/an, Ultra 10 €/mois ou 120 €/an, sans réduction ni achat réel. Export JSON schéma 4. Voir [les pauses créatives](docs/PAUSES_CREATIVES.md).

## Archive 0.17.0

## Version 0.17.0 — dé Selkie et coloriage

Quotidien ajoute deux pauses gratuites : le dé propose une activité, une application à laisser de côté ou un objectif sur les sept prochains jours ; tu confirmes chaque résultat avant son ajout au calendrier. Les objectifs restent volontaires et ne modifient ni les points, ni les limites, ni les verrouillages.

Le coloriage propose huit motifs originaux de 12 × 12 cases, dix couleurs, une gomme et Annuler/Rétablir sur les 50 derniers gestes de la page ouverte. Toucher/glisser ou commandes ligne/colonne : les pages s’enregistrent sur le téléphone et peuvent être effacées séparément. L’export JSON schéma 4 et l’effacement global incluent les coloriages. Aucun plugin, compte, image téléchargée ni permission supplémentaire.

[APK 0.17.0](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.17.0.apk) · [Sources exactes](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.17.0-source.zip) · [Validation](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/VALIDATION-0.17.0.md).

VersionCode 30, Android 10+, même certificat de développement. Le style, les seize lectures, le coach local et les offres sont conservés : Premium 5 €/mois ou 60 €/an ; Ultra 10 €/mois ou 120 €/an, sans réduction ni paiement réel. Voir [les pauses créatives](docs/PAUSES_CREATIVES.md).

## Archive 0.16.2

## Version 0.16.2 — voiles légèrement plus visibles

Seule l’intensité des voiles du fond Clair est renforcée : environ 20 % d’opacité relative supplémentaire, avec les mêmes couleurs, courbes et rythme. Les cartes, textes, sculptures, mise en page et mode Nuit sont conservés. Le contrôle de contraste continue de vérifier la superposition maximale.

[APK 0.16.2](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.16.2.apk) · [Sources exactes](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.16.2-source.zip) · [Validation](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/VALIDATION-0.16.2.md).

## Archive 0.16.1

## Version 0.16.1 — mouvement du fond clair

Le fond Clair ajoute deux larges voiles lavande et pêche qui ondulent lentement, avec des bords adoucis. La palette, les cartes, la mise en page, les sculptures en relief et le mode Nuit restent ceux de 0.16.0. Le mouvement utilise l’horloge existante et se fige si Android désactive les animations.

[APK 0.16.1](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.16.1.apk) · [Sources exactes](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.16.1-source.zip) · [Validation](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/VALIDATION-0.16.1.md).

## Archive 0.16.0

## Version 0.16.0 — volumes pastel et accueil réorganisé

Le mode Clair adopte un fond blanc doux, des cartes lavande, pêche et menthe, une navigation prune et des reliefs discrets. Un anneau, des billes et une capsule colorés flottent dans des zones décoratives séparées du texte : les dégradés, ombres et reflets donnent un effet 3D dessiné par le code, sans moteur 3D ni image téléchargée. Le fond est composé de deux lavis légers ; les octogones de 0.15.0 sont remplacés. Nuit conserve les vagues pointillées, avec une palette bleu nuit et lilas.

L’accueil place la présentation et son illustration, le résumé des points et du suivi, puis les applications suivies avant les raccourcis et le détail des points. Les cartes restent opaques. L’animation partage une seule horloge avec le parcours de bienvenue et s’arrête selon les réglages Android et le cycle de vie. Voir [l’apparence](docs/APPARENCE_CLAIRE.md).

[APK 0.16.0](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.16.0.apk) · [Sources exactes](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.16.0-source.zip) · [Validation](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/VALIDATION-0.16.0.md).

VersionCode 27, package `com.maree.app`, Android 10+. Le certificat de développement est conservé. Les seize lectures FR/EN, le coach local (1 152 / 23 040 / 50 688 questions préparées par langue), les règles et les données sont conservés. Premium reste à 5 €/mois ou 60 €/an ; Ultra à 10 €/mois ou 120 €/an, sans réduction. Cet APK de test ne comporte ni IA distante, ni achat réel, ni nouvelle permission. Les résultats de compilation, de tests et les limites des essais visuels sont consignés dans la validation de cette version.

## Archives

## Version 0.15.0 — poésies et octogones lumineux

Lecture ajoute huit poèmes complets sur la nature, le regard, le temps et l’effort. Les seize sélections sont disponibles hors ligne en français et en anglais, avec recherche par titre ou auteur et filtres Tout, Réflexion et Poésie. Les originaux, traductions préparées pour Selkie et conseils sont séparés ; seuls les textes nommés ont été sélectionnés, pas les recueils externes complets. Voir [la provenance](docs/LECTURES.md).

Le fond Clair remplace les six lignes par un champ d’octogones mobiles aux contours anthracite et lueurs corail. Les cartes restent opaques et les réglages Android des animations sont respectés. Le mouvement d’eau de Nuit est conservé.

[APK 0.15.0](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.15.0.apk) · [Sources exactes](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.15.0-source.zip) · [Validation](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/VALIDATION-0.15.0.md).

Les huit lectures précédentes, l’accueil, le calendrier, le coach local, les règles et les prix sont conservés. Les prix restent 5/10 €/mois et 60/120 €/an sans réduction ; aucun paiement réel dans cet APK de test.

## Archives

## Version 0.14.1 — deux lectures d’Ibn Taymiyya

Lecture ajoute deux courtes citations d’Ibn Taymiyya, avec original arabe, traductions françaises/anglaises préparées pour Selkie et références vérifiées dans deux éditions. Le catalogue compte désormais huit sélections et seize textes FR/EN ; les six lectures précédentes restent disponibles. Voir [la provenance](docs/LECTURES.md).

[APK 0.14.1](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.14.1.apk) · [Sources exactes](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.14.1-source.zip) · [Validation](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/VALIDATION-0.14.1.md).

Les passages portent sur le sens des actes et les bonnes actions quotidiennes. Le fragment de liste est signalé ; aucune redistribution de l’ouvrage complet ou de traduction commerciale moderne. Le nouveau parcours d’accueil, les règles, les prix et les autres fonctions sont conservés.

## Version 0.14.0 — accueil et guide simplifiés

Le premier lancement explique Selkie en trois étapes avant la configuration Android. L’accueil propose des raccourcis clairs et une carte des points plus compacte. Comprendre Selkie reste accessible depuis l’accueil et le menu, avec des liens directs vers les rubriques. Voir [le parcours](docs/ACCUEIL_ET_GUIDE.md).

[APK 0.14.0](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.14.0.apk) · [Sources exactes](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.14.0-source.zip) · [Validation](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/VALIDATION-0.14.0.md).

Les tâches, lectures, coach, règles de points et offres sont conservés. Notifications facultatives ; les accès restent ouverts seulement sur demande. Les prix et l’absence de paiement réel restent identiques.

215 tests réussis ; Android Lint : zéro erreur, cinq avertissements et quatre informations.

## Archives

## Version 0.13.0 — lectures hors ligne

Quotidien → Lecture ajoute six textes courts sur la méthode, l’observation, la patience et les habitudes. Lecture gratuite dans l’app, export .txt via Android, source et traduction indiquées. Les livres complets extérieurs ne sont pas présentés comme relus. Voir [la sélection et la provenance](docs/LECTURES.md).

[APK 0.13.0](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.13.0.apk) · [Sources exactes](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.13.0-source.zip) · [Validation](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/VALIDATION-0.13.0.md).

Les tâches du calendrier, les fonds, les offres et les catalogues de questions sont conservés. Les prix restent 5/10 €/mois et 60/120 €/an sans réduction ; paiements inactifs.

215 tests réussis ; Android Lint sans erreur, cinq avertissements et quatre informations.

## Archives

## Version 0.12.1 — calendrier de tâches et fond clair sobre

Le calendrier permet de choisir des dates passées ou futures et d’ajouter, modifier, cocher et supprimer des tâches personnelles gratuites. Le mode Clair remplace les étoiles multicolores par six lignes ondulantes monochromes. Le suivi, les offres et les 1 152 / 23 040 / 50 688 questions du Coach sont conservés.

[APK 0.12.1](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.12.1.apk) · [Sources](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.12.1-source.zip) · [Validation](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/VALIDATION-0.12.1.md).

Les observations de suivi restent limitées à 90 jours ; les tâches sont conservées jusqu’à suppression. L’export schéma 3 et l’effacement global couvrent les tâches. Les offres restent des démonstrations sans paiement, aux prix prévus de 5 € et 10 €/mois, sans réduction annuelle.

211 tests unitaires réussis ; Android Lint : zéro erreur, cinq avertissements et quatre informations.

## Archives

## Version 0.12.0 — calendrier et outils du quotidien

Quotidien est organisé en Jour, Calendrier, Bilan et Outils. Gratuit inclut le calendrier, le résumé hebdomadaire et les favoris du coach. Premium ajoute le détail hebdomadaire, les créneaux et le widget. Ultra ajoute les programmes Sommeil de 7 jours, Études de 14 jours et Réseaux sociaux de 30 jours. Tout fonctionne sur le téléphone, sans IA ni compte. Les observations de suivi sont locales, partielles et limitées à une fenêtre de 90 jours ; aucune durée ancienne ou journée parfaite n’est inventée.

Prix proposés inchangés : Premium 5 €/mois ou 60 €/an ; Ultra 10 €/mois ou 120 €/an, sans réduction. Les offres de l’APK DEBUG restent des démonstrations gratuites, sans paiement actif. Le coach conserve 1 152 / 23 040 / 50 688 questions préparées par langue, selon l’offre.

Les 204 tests unitaires passent. Android Lint indique 0 erreur, 5 avertissements et 3 informations.

[APK 0.12.0 sur GitHub](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.12.0.apk) · [Sources exactes](downloads/Selkie-Android-0.12.0-source.zip) · [Validation](downloads/VALIDATION-0.12.0.md) · [Fonctions et limites](docs/FONCTIONS_QUOTIDIENNES.md).

## Historique — les versions ci-dessous ont leurs anciens prix et fonctions

## Version 0.11.0 — Coach local et offres simplifiées

Le dialogue IA, le client de connexion et la préparation serveur ont été retirés. Aucun fournisseur, compte de coach ou permission Internet ne peut être activé par des options de compilation. Le coach à réponses préparées reste disponible sans compte et sans frais par question.

| Offre | Questions/réponses par langue | Applications suivies | Prix proposés |
| --- | ---: | --- | --- |
| Gratuit | 1 152 | 10 | 0 € |
| Premium | 23 040 | 50 | 5 €/mois ou 60 €/an |
| Ultra | 50 688 | Toutes les applications compatibles | 10 €/mois ou 120 €/an |

Les contenus combinent 48 situations, 24 intentions et des contextes pratiques rédigés en français/anglais ; ce ne sont pas 50 688 textes indépendants. Les offres restent des démonstrations gratuites, sans facturation. Les défis personnalisés et les règles de points sont conservés. Le fond Clair contient 96 formes multicolores plus visibles à luminosité variable ; Nuit ajoute ondulations croisées et rides circulaires. Les animations s’arrêtent selon le système et hors activité.

La politique locale et ses pages statiques ont été simplifiées. Les licences sont accessibles dans Confidentialité et données. Voir [les tâches de publication restantes](TACHES_RESTANTES.md), [le bilan des 19 points](docs/BILAN_CONFORMITE_FRANCE.md) et [le Coach](docs/COACH_HORS_LIGNE.md). L’identité publique, le public, la facturation et la publication sont à finaliser ; aucune certification juridique ou publication Play n’est annoncée.

[APK 0.11.0 sur GitHub](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.11.0.apk) · [Sources exactes](downloads/Selkie-Android-0.11.0-source.zip) · [Validation](downloads/VALIDATION-0.11.0.md).



## Version 0.10.4 — Coach par offre, animation claire et confidentialité

**Menu ☰ → Confidentialité et données** regroupe désormais trois pages FR/EN : **Conditions d’utilisation**, **Abonnements et résiliation**, **Éditeur et mentions**. Elles restent accessibles avant les autorisations. L’export JSON met les réglages et la progression à ta disposition, sans phrases du coach ni jetons de connexion ; la copie exportée reste séparée des données de l’application. L’effacement confirme ses écritures et retire les alertes. Les contours, libellés et commandes accessibles sont améliorés ; une vérification complète sur téléphone reste nécessaire.

L’APK de test fonctionne hors ligne **sans permission Internet**. Les liens, la messagerie et le fournisseur de fichiers que tu choisis restent des services distincts. Les prix proposés sont inchangés, sans réduction : Premium 10 €/mois ou 120 €/an ; Ultra 20 €/mois ou 240 €/an. Les offres restent des démonstrations gratuites : aucun achat, compte serveur ou dialogue IA distant n’est actif.

Le [bilan des 19 points](docs/BILAN_CONFORMITE_FRANCE.md) distingue **9 en place, 6 à compléter ou valider, 4 hors du périmètre actuel**. Il concerne ce prototype et ne constitue ni une certification ni une garantie contre les amendes. L’éditeur public reste à choisir ; Gmail, les droits sur les actifs et la diffusion doivent être finalisés. Voir le [guide de l’éditeur](docs/CONFIDENTIALITE_AVANT_PUBLICATION.md), le [registre et les demandes de droits](docs/REGISTRE_TRAITEMENTS.md), les [actifs et licences](docs/DROITS_ET_ACTIFS.md) et les [pages à héberger](legal-site/README.md). Aucune publication Play ni politique hébergée n’est annoncée ; les textes officiels actuels n’ont pas pu être vérifiés en ligne.

En mode Clair, 48 petites étoiles, losanges et anneaux dérivent et scintillent ; le mode Nuit conserve les vagues de points. Le réglage Android de réduction des animations reste respecté. Le Coach conserve la question en haut et la réponse en bas. Sa bibliothèque préparée propose par langue 1 152 questions en Gratuit, 5 760 en Premium et 10 368 en Ultra ; l’aide et la saisie standard restent accessibles gratuitement. Les conseils supplémentaires combinent situations, contraintes concrètes et intentions, sans modèle génératif.

Une connexion serveur Groq est préparée comme option pour un vrai dialogue IA, avec un éventuel quota gratuit à vérifier. Aucun compte, clé, service Supabase ou appel réel n’est activé. Le fournisseur public choisi pour le consentement devra correspondre à la configuration du serveur, sans repli automatique vers une API payante. Voir [l’option avec quota gratuit](docs/IA_AVEC_QUOTA_GRATUIT.md).

La page Abonnements et résiliation précise qu’une période déjà utilisée ou une simple annulation ne donne pas lieu à un remboursement automatique. Elle conserve les droits obligatoires applicables ; aucune clause générale supprimant ces droits n’a été ajoutée.

**117 tests unitaires réussis. Android Lint : 0 erreur, 4 avertissements, 1 information.**

[Page de l’APK Selkie 0.10.4 — environ 26 Mo, accès GitHub requis](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.10.4.apk) · [Sources exactes](downloads/Selkie-Android-0.10.4-source.zip) · [Validation](downloads/VALIDATION-0.10.4.md).

**English:** Privacy and data now groups Terms of use, Subscriptions and cancellation, and Publisher information. Export settings and progress as JSON, without Coach messages or sign-in tokens. Deletion is confirmed and alerts are removed. This offline APK has no Internet permission or real purchases. All 117 unit tests pass; Lint reports no errors, four warnings and one informational finding. Public-release and legal requirements remain to be finalised.

## Version 0.10.3 — surface d’eau pointillée

Le fond devient une **nappe de points répartie sur toute sa surface**, animée comme de l’eau. Les vagues et les points sont plus visibles, en clair comme en nuit ; les cartes restent opaques pour garder les textes lisibles. La boucle de mouvement dure 12 secondes. Le réglage Android de suppression des animations et la pause quand l’activité quitte le premier plan sont conservés.

Le menu ☰, les quatre onglets, le coach, les données, les règles et les prix sans réduction restent identiques. Aucun compte, paiement ou dialogue IA distant n’est activé. Compilation et 97 tests unitaires réussis, Android Lint sans erreur. Le fond et son mouvement, son arrêt et sa reprise ont été observés en clair et en nuit sur émulateur ; les essais sur téléphone restent à faire.

[Page de l’APK Selkie 0.10.3 — environ 25 Mo, accès GitHub requis](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.10.3.apk) · [Sources exactes](downloads/Selkie-Android-0.10.3-source.zip) · [Validation](downloads/VALIDATION-0.10.3.md) · [Apparence](docs/MODE_NUIT.md).

**English:** A field of dots now covers the background and moves like a water surface. The waves are more visible in Light and Night modes, while cards remain opaque. The 12-second loop respects Android’s animation setting and pauses outside the foreground. Coach content, menus and planned prices stay the same. The build and all 97 unit tests pass with no Lint errors. Movement, stopping and resuming were observed in both modes on an emulator; physical-phone testing remains pending.

## Version 0.10.2 — formes en points et onde douce

Le fond dessine désormais **144 points** répartis sur deux cercles, un triangle arrondi et un losange. Une onde serpente sur leurs contours, avec une dérive légère et une boucle de 24 secondes. Les points restent discrets, en clair comme en nuit ; les cartes restent opaques. Le réglage Android des animations et la pause hors de l’activité visible sont conservés.

Le menu ☰, les quatre onglets, les 1 152 questions par langue, les règles, les données et les prix sans réduction restent identiques. Cette version de test n’active aucun compte, paiement ou dialogue IA distant. Compilation et 97 tests unitaires réussis, Android Lint sans erreur. Le mouvement, son arrêt et sa reprise ont été observés sur émulateur ; les essais sur téléphone restent à faire.

[Page de l’APK Selkie 0.10.2 — environ 24 Mo, accès GitHub requis](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.10.2.apk) · [Sources exactes](downloads/Selkie-Android-0.10.2-source.zip) · [Validation](downloads/VALIDATION-0.10.2.md) · [Apparence](docs/MODE_NUIT.md).

**English:** The background uses 144 dots to outline two circles, a rounded triangle and a diamond. A gentle travelling wave moves around the outlines on a 24-second loop, respecting Android’s animation setting. Menus, Coach content, rules and planned prices stay the same. The build and all 97 unit tests pass, with no Lint errors. Movement, stopping and resuming were observed on an emulator; physical-phone testing remains pending.

## Version 0.10.1 — menu organisé et fond géométrique

Le bouton **☰ en haut à droite** ouvre un menu organisé : **Réglages** (Langue, Apparence, Accès Android), **Offres** (Abonnements) et **Informations** (Règles de Selkie, Confidentialité et données). Chaque choix ouvre une page dédiée ; les boutons Retour et les quatre onglets du bas permettent de revenir à l’utilisation quotidienne. Le badge de l’offre et l’accès Premium depuis Défis ouvrent directement Abonnements. Des cercles, un triangle et un losange se déplacent doucement en arrière-plan. Les couleurs suivent le thème ; les cartes restent opaques et les réglages Android de suppression des animations sont respectés.

La barre du bas contient **Accueil, Quotidien, Défis et Coach**. Le coach hors ligne, ses 1 152 questions par langue, les deux cartes question/réponse, le mode Nuit, les points, les données et les prix sans réduction restent conservés. La politique complète et l’effacement sont accessibles dans Confidentialité et données. Le résumé initial des autorisations conserve aussi son lien de confidentialité.

[Page de l’APK Selkie 0.10.1 — accès GitHub requis](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.10.1.apk) · [Sources exactes](downloads/Selkie-Android-0.10.1-source.zip) · [Validation](downloads/VALIDATION-0.10.1.md) · [Menu](docs/MENU.md).

**English:** Tap **☰ at the top right** for Settings (Language, Appearance, Android access), Plans (Subscriptions) and Information (Selkie rules, Privacy and data). Home, Daily, Challenges and Coach stay in the bottom bar. Soft geometric shapes drift behind the screens, respecting Android’s animation setting. Accounts and real purchases remain inactive in this test APK.

## Version 0.10.0 — bibliothèque du coach et mode nuit

Le Coach ajoute **1 152 questions et réponses préparées par langue**, classées en huit rubriques, avec recherche et pagination. Elles combinent 48 situations concrètes et 24 types de conseils ; les alias ne sont pas comptés comme des questions supplémentaires. Les 67 sujets existants et les 38 questions d’aide Selkie restent disponibles. La question se trouve dans une carte en haut, et la réponse dans une autre carte immédiatement dessous. Une réponse ancienne est masquée quand la question est modifiée.

Le **mode Nuit noir et bleu** est accessible dans **Plus → Apparence**, avec les choix Clair, Nuit et Comme le téléphone. Le choix est local et conservé ; les règles, points, limites, langues et textes des défis personnels sont conservés. Le logo et l’écran rouge de blocage gardent leur identité. Les tarifs annuels restent sans réduction : Premium 120 €/an, Ultra 240 €/an ; aucun paiement réel n’est actif.

[Page de l’APK Selkie 0.10.0 — accès GitHub requis](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.10.0.apk) · [Sources exactes](downloads/Selkie-Android-0.10.0-source.zip) · [Validation](downloads/VALIDATION-0.10.0.md) · [Bibliothèque du Coach](docs/COACH_HORS_LIGNE.md) · [Apparence](docs/MODE_NUIT.md).

**English:** The offline coach includes 1,152 prepared question-and-answer pairs, with search and eight categories. Your question is above a separate answer card. Choose Light, Night or Follow phone in More → Appearance. Advice remains rule-based and offline; payments, accounts and remote AI chat are not active.

## Version 0.9.3 — tarifs annuels sans réduction

Les offres annuelles correspondent désormais à douze mensualités : **Premium 10 €/mois ou 120 €/an**, **Ultra 20 €/mois ou 240 €/an**. Les textes de remise et d’économie sont retirés des offres et des réponses du Coach, en français et en anglais. Les fonctions des offres sont identiques pour les deux durées ; les achats restent inactifs dans cet APK de test.

[Page de Selkie 0.9.3 sur GitHub — accès au dépôt requis](https://github.com/abdulmalikkakar48-blip/Code-1.1/blob/maree-apk-download/downloads/Selkie-Android-0.9.3.apk) · [Aide au téléchargement](docs/TELECHARGER_APK.md) · [Sources exactes](downloads/Selkie-Android-0.9.3-source.zip) · [Validation](downloads/VALIDATION-0.9.3.md) · [Offres actuelles](docs/ABONNEMENTS_ET_COMPTES.md).

Les versions ci-dessous sont des archives ; leurs anciens tarifs ne sont pas ceux de la version actuelle.

## Version 0.9.2 — français et anglais

Selkie propose désormais **Français / English**, dès l’accueil initial et dans **Plus → Langue / Language**. Les écrans, offres, notifications, défis proposés, politique et coach hors ligne sont traduits. Chaque langue contient 67 sujets et 125 réponses préparées, dont 38 questions d’aide. La réponse suit la langue choisie, sans traducteur en ligne. Les points, limites et défis personnels sont conservés.

[Télécharger Selkie 0.9.2](downloads/Selkie-Android-0.9.2.apk) · [Sources exactes](downloads/Selkie-Android-0.9.2-source.zip) · [Validation](downloads/VALIDATION-0.9.2.md) · [Fonctionnement des langues](docs/LANGUES.md) · [English privacy policy](docs/PRIVACY_POLICY_EN.md).

**English:** Choose **English** on the welcome screen or in **More → Langue / Language**. The app, built-in challenges and offline coach now include English. Your points, limits and custom challenge text stay intact. Accounts, real payments and online AI chat are not active in this test version.

## Version 0.9.1 — aide Selkie et offres annuelles

Le même Coach répond désormais aux questions sur l’application et propose des conseils de temps d’écran : **38 questions d’aide dans sept rubriques et 29 sujets de conseils**, soit 67 sujets et 125 réponses préparées. Dans **Coach → Comprendre Selkie**, les réponses sur les limites, points, défis, données, offres et comptes sont consultables directement. Les demandes reconnues sur l’application proposent une aide adaptée ; les conseils restent disponibles hors ligne.

[Télécharger Selkie 0.9.1](downloads/Selkie-Android-0.9.1.apk) · [Sources exactes](downloads/Selkie-Android-0.9.1-source.zip) · [Validation](downloads/VALIDATION-0.9.1.md).

Le contact devient **1kabdm@gmail.com**. Les tarifs prévus sont **Premium 10 €/mois ou 110 €/an**, **Ultra 20 €/mois ou 220 €/an**, avec l’équivalent d’un mois offert sur l’année. L’aide explique le renouvellement et la résiliation Google Play ; désinstaller l’application n’annule pas un abonnement acheté. Les offres restent des démonstrations gratuites : aucun paiement réel n’est intégré. Un compte avec un seul téléphone connecté à la fois est prévu, mais aucun service de comptes ou de restauration des achats n’est actif. Voir [les décisions et les étapes restantes](docs/ABONNEMENTS_ET_COMPTES.md).

La signature de test est identique à celles des APK 0.8.1 et 0.9.0. Le suivi, les points, les défis, le phoque et le design retenu sont conservés.

## Version 0.9.0 — coach gratuit hors ligne

Le Coach propose désormais un champ de discussion utilisable sans compte ni service à activer : 40 sujets, 120 conseils préparés, fautes légères reconnues, variantes et boutons de suggestions. Il peut utiliser les points et compteurs locaux réels. Il s’agit d’un coach à règles, explicitement présenté comme tel ; le dialogue IA distant reste à activer séparément.

[Télécharger Selkie 0.9.0](downloads/Selkie-Android-0.9.0.apk) · [Sources](downloads/Selkie-Android-0.9.0-source.zip) · [Fonctionnement et confidentialité](docs/COACH_HORS_LIGNE.md) · [Validation](downloads/VALIDATION-0.9.0.md).

La conversation n’est pas archivée. La conservation des questions non comprises est facultative, désactivée par défaut, limitée à 50 phrases sur le téléphone et effaçable. Les messages de détresse reconnus invitent à une aide humaine. Aucun message du coach local n’est envoyé à un service ni facturé. Le logo corrigé et le design retenu sont conservés.

Cette version de test reprend la même clé que 0.8.1 ; une installation 0.8.1 signée avec ce certificat peut être mise à jour. L’archive 0.8.0 à autre certificat garde ses contraintes de réinstallation. Les paiements et la publication Play restent à préparer.

## Version de test 0.8.1 — icône corrigée

[Télécharger Selkie 0.8.1](downloads/Selkie-Android-0.8.1.apk) · [Code source de cette version](downloads/Selkie-Android-0.8.1-source.zip) · [Validation](downloads/VALIDATION-0.8.1.md).

Le phoque utilise désormais des marges proportionnelles dans l’icône adaptative du téléphone. Le logo, les couleurs et les autres écrans de la refonte restent conservés. Cette compilation contient également le code de conversation préparé précédemment ; le dialogue IA reste **à activer**, sans comptes Supabase/OpenAI configurés. Aucun paiement n’est actif.

L’éditeur a accepté une réinstallation : ce fichier emploie la signature de développement déjà disponible dans cet environnement, différente de celle de l’APK 0.8.0 à signature fixe. Android peut donc demander de désinstaller cette version précédente ; la désinstallation efface ses données locales. La clé privée n’est pas publiée. La version 0.8.0 et ses sources restent archivées sous leurs noms précédents.

## Connexion du Coach en préparation

Le code Android intègre désormais une conversation authentifiée par code e-mail et un client HTTPS vers le serveur IA, avec réponses OpenAI, historique limité et gestion du quota. **Le service reste à activer** : aucun compte Supabase ou OpenAI API n’est encore configuré. Voir [les étapes d’activation](docs/ACTIVER_COACH_IA.md). L’APK 0.8.1 inclut ce client sans configuration publique ; il affiche cet état sans simuler de réponse IA. L’APK 0.8.0 ci-dessous est conservé comme archive du design.

## Version de référence pour la suite

La refonte moderne retenue le 11 octobre 2026 reste la base du design. Son APK 0.8.0 à signature fixe est une archive ; les versions de test depuis 0.8.1, dont 0.10.4, utilisent la clé de développement existante. Le code, les APK et les sources sont conservés sur `maree-apk-download`. Voir [la version de référence et le travail restant](docs/VERSION_REFERENCE.md).

## Refonte moderne et signature fixe

La dernière refonte adopte des titres sans empattement, du vert profond, une menthe lumineuse, une navigation foncée et un accueil avec deux indicateurs distincts. Le fonctionnement local et les règles existantes sont conservés.

[Télécharger l’APK de la refonte](downloads/Selkie-Android.apk). L’APK utilise désormais une **nouvelle clé fixe sauvegardée séparément**, avec l’accord de l’éditeur. Elle remplace les clés de test temporaires. Le certificat est contrôlé avec l’outil officiel Android ; voir [la validation](downloads/VALIDATION.md) et [la procédure de signature](docs/SIGNATURE_ANDROID.md). Cette version garde le numéro 0.8.0 et reste un APK de test.

Cette signature est différente de celle de l’ancienne application. Android ne permet pas une mise à jour par-dessus une installation ayant un autre certificat ; une désinstallation efface les données locales. Les captures déjà présentes montrent la version précédente.

## Mise à jour 0.8.0

**Selkie** est le nom choisi par l’éditeur pour remplacer Milo. Son usage commercial reste à vérifier. Nouveau logo de phoque noir sur fond menthe, inspiré de la selkie. Refonte native avec fond blanc cassé, texte vert profond, cartes blanches et boutons cohérents. L’accueil distingue le capital de points des applications suivies ; les actions secondaires d’une application sont regroupées dans son menu. La liste de suivi utilise un défilement progressif, y compris pour les grandes listes Ultra.

Les cinq onglets restent Accueil, Quotidien, Défis, Coach et Plus. Les défis affichent les trois étapes personnelles sur trois lignes, puis les journées dans l’ordre ; les calendriers des défis proposés se déplient pour lire chaque journée. Le quotidien propose une pause et un bilan des compteurs, avec une explication consultable. Le Coach ouvre directement les conseils fixes hors ligne et indique l’état du futur dialogue IA. Les accès Android sont expliqués avant le suivi ; la confidentialité commence par un résumé et conserve le texte complet.

Le paquet Android, les préférences et les règles sont conservés : 10 / 50 / sans plafond, restrictions à 0 point, trois étapes personnelles, durée de 2 à 365 jours et récompense de 0,25 point à la fin. Voir [les règles de design](docs/DESIGN_SELKIE.md) et [les captures Android réelles](downloads/screenshots/README.md).

L’éditeur a demandé Lovable, Figma et MagicPath. Les liens fournis désignent leurs fiches ; leurs outils ne sont pas accessibles dans cette session. Cette refonte est réalisée dans le code Kotlin/Compose et ne prétend pas provenir de ces services.

## Mise à jour 0.7.0

À cette version, le nom choisi était **Milo**. L’icône pause/temps, l’onglet Coach et la présentation des journées sur des lignes séparées ont été ajoutés. Le nom est remplacé par Selkie en 0.8.0 ; l’identité Android et les données locales restent les mêmes.

## Mise à jour 0.6.0

Plafonds : **10 applications en Gratuit**, **50 en Premium** et **aucun plafond commercial en Ultra** (applications compatibles du téléphone). Une baisse d’offre conserve les données et bloque uniquement les nouveaux ajouts au-delà du plafond. Les restrictions à 0 point restent actives dans toutes les offres. Le [choix des plafonds](docs/CALIBRAGE_OFFRES.md) expose la justification et les limites de la comparaison.

## Mise à jour 0.5.0

À cette version, le nom **Marée** était conservé et le logo associait pause, progression et accents menthe/corail. L’identifiant Android et les données restent stables pour la mise à jour. Voir [l’identité visuelle](docs/IDENTITE_VISUELLE.md).

Pour commencer la distribution et les paiements, ouvre [le guide de démarrage](docs/DEMARRER_PUBLICATION.md). Il mène aux étapes [Google Play](docs/PUBLICATION_GOOGLE_PLAY.md) et [abonnements](docs/ABONNEMENTS.md). Le travail porte sur Android ; la version iPhone est reportée. L’APK reste une version de test ; aucun paiement ni coach IA n’est connecté.

**Version actuelle : 0.10.4 (APK de test et code source).** Interface française et anglaise, apparence claire ou nuit.

Ce projet suit le cahier des charges fourni, en Kotlin + Jetpack Compose Material 3, `minSdk 29` (Android 10), `targetSdk 34`, package `com.maree.app`, Gradle 8.7, AGP 8.5.2, Kotlin 1.9.24.

## Mise à jour 0.4.0

- La règle de 0 point s’applique à toutes les offres : aucun ajout ou changement de limite à 0 point. Une réinitialisation exige réellement ses 10 points ; le retrait d’une application et l’effacement des données restent disponibles.
- Offres recalibrées en 0.6.0 : Gratuit, 10 applications ; Premium, 50 applications pour 10 €/mois ; Ultra, toutes les applications compatibles du téléphone sans plafond commercial pour 20 €/mois. L’APK de test affiche un mode démonstration gratuit dans le menu ☰ → Abonnements, pour tester les limites et les fonctions locales. Il ne vend aucun abonnement et n’effectue aucun paiement.
- Défis → Mes défis : Premium et Ultra permettent de créer un titre avec exactement trois étapes et une durée choisie de 2 à 365 jours. Les trois étapes doivent être cochées pour valider une journée. Les jours peuvent être espacés ; ces défis sont indépendants de la rotation standard de 21 jours. La récompense totale est de 0,25 point une seule fois après la durée choisie. Elle n’augmente pas le compteur de bonus des défis Selkie.
- Les points sont enregistrés en quarts entiers, pour conserver exactement 0,25 / 0,50 / 0,75 point. Les anciens soldes sont migrés une fois sans perte ni double crédit. Les cases du jour et la progression survivent à la relance.
- Ultra ajoute la recherche dans les applications suivies et le tri par nom, temps passé ou proximité de la limite. Le coach IA illimité par messages est prévu pour Ultra, mais reste à développer et à financer.

Les défis personnels terminés peuvent être supprimés sans retirer les points acquis. Recréer un défi demande de nouvelles journées de pratique depuis zéro. Un retour à Gratuit conserve les applications et défis existants, mais empêche les nouveaux ajouts au-delà de son plafond et la validation des défis personnels réservée à Premium/Ultra.

## Mise à jour 0.3.0

Chaque défi demande désormais **5 jours de pratique**, avec une validation par jour selon la date locale du téléphone. L’écran Défis affiche les jours accomplis et un bouton « Valider aujourd’hui ». Les jours peuvent être espacés : une journée manquée n’efface pas la progression. Aucun jour antérieur ne peut être ajouté. Le bilan Quotidien indique également les validations du jour.

Les points sont attribués après des défis entièrement terminés : **+5 points tous les 5 défis complets cumulés**, sans bonus pour les jours intermédiaires. Les séries continuent d’alterner tous les 21 jours ; leur renouvellement efface la progression de la série précédente. Les points, totaux et défis déjà terminés dans une ancienne version sont conservés, sans nouvelle récompense.

## Mise à jour 0.2.1

La politique affiche **Abdul Malik Kakar** comme responsable à titre personnel, avec le contact **1kabdm@gmail.com**, tous deux fournis par l’éditeur. La mise à jour conserve le fonctionnement et les données de la version 0.2.0.

## Mise à jour 0.2.0

- Premier lancement : explication des autorisations avant l’accueil, avec accès à la confidentialité. L’accès aux données d’utilisation et la surcouche sont nécessaires au suivi ; les notifications restent facultatives. Un mode découverte fonctionne sans suivi. Une mise à jour depuis 0.1.0 présente aussi cet accueil, sans effacer les limites, points ou défis.
- Navigation initiale : Accueil, Quotidien, Défis et Plus ; Coach est ajouté en 0.7.0. Quotidien regroupe le bilan des compteurs suivis, une idée de pause et la carte du futur coach. Les mesures sont masquées lorsque le suivi est en pause.
- Thème clair crème, vert, corail, lavande et sable ; icônes de navigation vectorielles.
- Pause du suivi et gestion des autorisations depuis Plus. Ni le démarrage du téléphone ni une permission déjà accordée ne démarrent le suivi avant la fin du parcours et son activation.
- Politique hors ligne dans l’accueil et Plus, contact fourni par l’éditeur, suppression locale avec confirmation. La suppression arrête le suivi et retire limites, verrous, points, défis et choix d’accueil, puis revient au parcours initial. Elle ne révoque pas les permissions Android et ne supprime pas les statistiques détenues par Android.

La politique est une information pour la version locale, pas une certification juridique. L’identité du responsable et son contact sont renseignés. Les conditions et transferts de la messagerie de contact restent à vérifier avant diffusion publique. Voir [le texte de confidentialité](docs/CONFIDENTIALITE.md) et [les points avant publication](docs/CONFIDENTIALITE_AVANT_PUBLICATION.md).

## Ce qui est codé dans l'application Android

- Sélection des applications installées disposant d'une icône de lancement ; limite quotidienne par paliers de 5 minutes, à partir de 5 minutes, 30 minutes par défaut.
- Maximum de 10 applications en gratuit ; modification et suppression de la liste.
- Mesure en millisecondes de l'utilisation au premier plan à partir de `UsageStatsManager` / `UsageEvents` ; affichage du temps en minutes et d'une barre de progression.
- Avertissement à 80 % (une fois par application et par jour, sous réserve de l'autorisation des notifications).
- Verrou de 24 h à partir de l'atteinte de la limite, surcouche rouge `TYPE_APPLICATION_OVERLAY` au-dessus de l'application suivie, bouton d'accueil, compte à rebours. Le service réévalue le suivi toutes les 2 secondes.
- Déblocage après 24 h et remise de la limite complète via une base locale (Android ne remet pas ses propres compteurs à zéro). Réinitialisation anticipée à −10 points, retrait de l'application qui supprime son verrou.
- Points d'honneur : 100 au départ, minimum 0 ; +10 par période de 24 h respectant les limites, −5 pour la réouverture d'une app verrouillée (une fois au maximum par 30 s), −10 pour la réinitialisation, +5 tous les 5 défis cumulés.
- Deux séries de 10 défis, en alternance tous les 21 jours. Chaque défi demande 5 validations sur des jours différents, une au maximum par date locale. Un défi terminé n’est récompensé qu’une fois par cycle.
- Blocage des ajouts et changements de limite à 0 point dans toutes les offres ; réinitialisation à partir de 10 points. Les défis permettent de regagner des points.
- Redémarrage du service après démarrage du téléphone *lorsque le système l'autorise*.

## Ce qui reste à activer / développer

- **Coach IA** : client de conversation et authentification par code e-mail implémentés dans le code Android ; serveur Supabase/OpenAI préparé avec quota des 100 questions. Les services et accès ne sont pas encore configurés, donc aucun dialogue réel n’est actif. Le client conditionnel est présent dans 0.10.4, avec ses identifiants publics vides et sans permission Internet dans l’APK hors ligne ; aucun compte ou service n’a été créé. Voir [l’activation](docs/ACTIVER_COACH_IA.md).
- **Premium et Ultra** : les prix de lancement prévus sont affichés, avec un mode de démonstration gratuit dans l’APK debug. Aucun abonnement n’est vendu. Avant commercialisation, remplacer le statut de démonstration local par des droits vérifiés côté serveur, Google Play Billing ou l’équivalent Galaxy Store et des comptes développeur actifs. Le mode de démonstration ne doit pas servir de validation d’abonnement. Pour les abonnements numériques sur Google Play, utiliser Google Play Billing dans le parcours standard. Stripe sert surtout au site web ; les programmes de paiement alternatif demandent une éligibilité et des règles spécifiques. Voir [le guide des abonnements](docs/ABONNEMENTS.md).
- **Compte email et sauvegarde cloud** : tables RLS Supabase préparées mais pas encore reliées à l'APK. Les données actuelles sont locales dans `SharedPreferences` et `allowBackup=false`.
- **Tests sur un téléphone Samsung réel et distribution** : nécessaires avant mise en production.

## Obtenir l'APK avec GitHub Actions

1. Créer un dépôt GitHub vide et y envoyer **le contenu** de ce répertoire (`app/`, `.github/`, etc.).
2. Ouvrir l'onglet **Actions**, sélectionner **Construire l'APK Android**, puis lancer **Run workflow** (ou envoyer un commit sur `main`).
3. À la fin de la tâche `android`, récupérer l'artefact `Selkie-build-to-sign` ; il contient `app-debug.apk`. C’est un fichier intermédiaire qui utilise la clé temporaire du runner.
4. Pour une mise à jour de l’APK de test actuel, recompiler avec **la clé de développement existante**, conserver son certificat indiqué ci-dessous et augmenter le versionCode au-delà de celui installé. Ne pas créer une nouvelle clé ni utiliser la clé fixe de l’archive 0.8.0. La clé du runner seule ne garantit pas une mise à jour compatible. L’APK de test actuel est [Selkie-Android-0.10.4.apk](downloads/Selkie-Android-0.10.4.apk), pour Android 10+.
5. Ouvrir Selkie, lire les explications, puis activer les accès nécessaires au suivi. Les notifications sont facultatives, et le mode découverte reste disponible.

Le projet a été compilé dans l'environnement cloud. L'APK de test est généré dans `app/build/outputs/apk/debug/app-debug.apk`. Le wrapper Gradle 8.7 est inclus, avec vérification SHA-256 de sa distribution ; GitHub Actions utilise ce wrapper pour compiler, exécuter les tests unitaires et lancer Android Lint.

## Compilation locale avec Android Studio

1. Ouvrir le dossier dans **Android Studio** avec **JDK 17** et Android SDK API 34 installé.
2. Laisser Android Studio synchroniser le projet avec le wrapper Gradle fourni.
3. Lancer **Build > Build APK(s)**, ou utiliser :

```sh
./gradlew --no-daemon :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
```

Sous Windows, utiliser `gradlew.bat`. Définir `ANDROID_HOME` vers le SDK installé ou renseigner `sdk.dir` dans un fichier local `local.properties` non versionné.

## Développement dans cet environnement cloud

Java 17, Gradle 8.7 et le SDK Android 34 sont installés sous `/workspace/.cloud-setup`. Les caches et la configuration Java restent hors du code source. Pour réactiver les outils dans un nouveau terminal :

```sh
source /workspace/.cloud-setup/activate.sh
cd /workspace/Code-1.1
./gradlew --no-daemon --max-workers=2 :app:assembleDebug :app:testDebugUnitTest :app:lintDebug
```

L'activation utilise le proxy et le certificat de confiance fournis par la plateforme, avec vérification TLS conservée. Aucun secret n'est nécessaire pour les fonctions locales de cette version. Le script d'installation et les instructions de démarrage sont également enregistrés dans la configuration de l'environnement.

Les tests de `SetupPreferencesTest` couvrent l’absence de démarrage avant l’accueil, le mode découverte, la pause/reprise et le caractère facultatif des notifications. Le test de suppression de `StoreTest` vérifie l’effacement des verrous, points, défis, dates de validation et clés supplémentaires, puis une reprise propre. Les tests de défis vérifient les cinq jours distincts, les doubles validations et les redémarrages, les jours espacés, minuit et le changement d’heure, les récompenses après des défis complets, les rotations et la conservation des anciens défis sans recréditer les points. Les autres tests de `StoreTest` couvrent les avertissements à 80 %, les verrous de 24 h, les récompenses et pénalités et les réinitialisations. Le rafraîchissement de l'interface laisse au service la création des alertes et verrous ; un redémarrage du service n'entraîne plus de pénalité à sa première observation. La liste des applications est chargée en arrière-plan, avec un indicateur de chargement et une action de nouvelle tentative en cas d'erreur.

## Limites de fonctionnement Android et précautions

- Android ne garantit pas un blocage inviolable : la désinstallation de Selkie, la révocation de ses autorisations, certains modes économie d'énergie Samsung, la mise en veille du service ou les restrictions de fenêtre superposée peuvent interrompre le suivi et le blocage. L'application **ne prétend pas empêcher ces actions**.
- Une surcouche `TYPE_APPLICATION_OVERLAY` ne recouvre pas nécessairement toutes les zones système et Android peut intercepter le geste de retour ou protéger l'écran verrouillé. Le bouton d'accueil est prévu ; la gestion des gestes système dépend du téléphone.
- Les statistiques `UsageEvents` peuvent avoir un délai, des événements manquants et des particularités sur plusieurs fenêtres. Les sessions encore ouvertes **depuis avant minuit** peuvent être sous-comptées après minuit. Le projet est un prototype à tester sur Samsung avant diffusion.
- Le suivi lit les événements d'utilisation à partir de minuit à chaque contrôle. Ce fonctionnement simple peut être optimisé pour limiter le coût énergétique sur les téléphones plus lents.
- Les récompenses de 24 h se basent sur les incidents observés pendant l'exécution ; après une longue interruption, certaines limites historiques ne peuvent plus être vérifiées parfaitement. Au maximum 7 périodes sont rattrapées par traitement.
- Lorsqu'une application est retirée pendant une période, une limite précédemment franchie demeure considérée comme une rupture de discipline pour la période (choix explicite sur un point resté ouvert dans le cahier).
- Avant Google Play, vérifier les politiques actuelles concernant `PACKAGE_USAGE_STATS`, les surcouches et le type `FOREGROUND_SERVICE_SPECIAL_USE`. Une justification du service au premier plan est incluse dans le manifeste.

## Backend Supabase préparé (non branché)

Le document décrit un projet Supabase déjà créé, ainsi que la table `public.days` du prototype web. Le script `supabase/migrations/20261010_maree.sql` crée de nouvelles tables **sans modifier la table `days`** :

- `profiles` (statut premium géré côté serveur),
- `user_state` (charge utile JSON de sauvegarde),
- `coach_usage` (quota IA, avec sécurité par ligne),
- `consume_coach_credit()` (RPC transactionnelle atomique et limitée aux utilisateurs authentifiés).

Pour déployer l'exemple côté serveur :

```sh
supabase link --project-ref VOTRE_NOUVEAU_PROJET_SELKIE
supabase db push
supabase secrets set OPENAI_API_KEY="VOTRE_CLE_PRIVEE"
supabase functions deploy coach
```

**Ne pas utiliser ces commandes sans vérifier et sauvegarder les données préexistantes.** Le dialogue préparé demande la migration complémentaire, la liste de testeurs, l’authentification e-mail configurée et l’URL/clé publique du projet dans une nouvelle compilation Android. Suivre [le guide d’activation](docs/ACTIVER_COACH_IA.md), puis tester une vraie réponse avant distribution. La synchronisation du suivi n’est pas nécessaire au coach et n’est pas implémentée. La clé OpenAI reste uniquement sur le serveur.

## Structure du projet

```text
app/src/main/java/com/maree/app/
  MainActivity.kt       → navigation, limites, choix de suivi et suppression
  OnboardingScreen.kt  → explications et autorisations avant l’accueil
  SetupPreferences.kt  → fin de parcours et activation/pause du suivi
  DailyScreen.kt        → bilan du jour, conseils et futur coach
  PrivacyContent.kt    → texte et identité de confidentialité
  PrivacyScreen.kt     → résumé, politique hors ligne et contact
  CoachScreen.kt       → écran Coach et conseils fixes hors ligne
  ChallengeDays.kt     → journées de pratique en lignes ordonnées
  MareeTheme.kt         → palette et typographie communes
  UiComponents.kt      → titres, cartes, badges et boutons communs
  Membership.kt         → offres, quarts de point et modèles de défis personnels
  MembershipScreen.kt   → offres prévues et démonstration gratuite
  CustomChallengesScreen.kt → formulaire et étapes des défis personnels
  Store.kt              → SharedPreferences, règles des points, cycles et verrous
  UsageReader.kt        → événements d'activité et temps d'écran
  MonitorService.kt     → surveillance, notifications, pénalités
  LockActivity.kt       → écran rouge et surcouche Android
  BootReceiver.kt       → tentative de reprise après redémarrage
.github/workflows/build.yml → génération de l'APK de test
supabase/                   → migration SQL et fonction coach (préparation)
```

## Confidentialité

Le moteur de suivi fonctionne en local. L'APK ne contient pas de clé API, n'envoie pas les statistiques à un serveur et ne sollicite pas de paiement. Le backend Supabase est fourni à titre de code de préparation ; aucune fonction cloud n'est exécutée par cette version de l'APK.

## Signature des tests actuels et anciennes archives

Selkie 0.10.4 utilise la clé de développement existante, certificat SHA-256 `9a7487f626169300b57b897c488827428b9517ac8bac8a805f6508fddb932a50`. Les prochaines mises à jour de cette chaîne doivent réutiliser cette clé, avec un versionCode supérieur au précédent, sans générer de nouvelle clé. Vérifier le certificat avec `apksigner` avant distribution ; la clé du runner GitHub Actions peut être différente et ne suffit pas à garantir la compatibilité. La clé privée et ses secrets restent hors du dépôt et des archives sources.

`downloads/Selkie-Android.apk` (0.8.0) et la procédure `tools/sign_apk.py` à clé fixe appartiennent à l’ancienne chaîne de signature ; son certificat `c3def…` est incompatible avec celui des tests actuels. Voir [l’ancienne procédure](docs/SIGNATURE_ANDROID.md). Pour une future publication Google Play, préparer une clé d’importation dédiée et la configuration Play App Signing séparément : la clé de test n’est pas une clé de production. Aucun changement de clé ni compte Play n’est effectué par ces instructions.

Les tests de la version 0.4.0 couvrent aussi la migration unique des soldes, les quarts exacts, la règle de 0 point pour chaque offre, les plafonds et le retour à Gratuit, le coût complet d’une réinitialisation et les défis personnels (durées de 2 et 7 jours, trois étapes persistées, récompense unique, relance, suppression et effacement). Le schéma Supabase préparatoire représente encore l’abonnement par un booléen : les droits des trois offres et les quotas du futur coach devront être reliés à une vérification d’achat côté serveur avant leur commercialisation.
